export interface Project {
  title: string;
  description: string;
  githubLink: string;
  technologies: string[];
  showcaseImage: string;
}
