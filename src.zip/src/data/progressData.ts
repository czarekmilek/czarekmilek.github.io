export const progressData = [
  { progress: 90, label: "TypeScript" },
  { progress: 90, label: "JavaScript" },
  { progress: 80, label: "Python" },
  { progress: 80, label: "CSS" },
  { progress: 75, label: "HTML" },
  { progress: 60, label: "C++" },
  { progress: 45, label: "Java" },
];

export const frameworkData = [
  { progress: 70, label: "React" },
  { progress: 50, label: "Vue.js" },
  { progress: 35, label: "Node.js" },
];
