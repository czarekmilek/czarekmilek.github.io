export const ExpList = [
  {
    id: 1,
    title: "Tutor",
    years: "2021-2022",
    responsibilities:
      "Teaching mathematics and english, helping to understand concepts and improve problem-solving skills. ",
    desc: "I tutored primary school and high school students",
    logo: "./math.jpg",
    link: "",
  }
];
